import { summarize } from '../src/ai/autopsy.js';
let passed = 0, failed = 0;
const ok = (c, m) => { c ? (passed++, console.log(`  ok  ${m}`)) : (failed++, console.log(`  FAIL ${m}`)); };
const T = (o) => ({ symbol: 'X', side: 'LONG', leverage: 10, entry_price: 100, exit_price: 100, sl_price: 99.7, tp_price: 100.9, realized_pnl: 0, close_reason: 'sl', opened_at: '2026-11-01T00:00:00Z', closed_at: '2026-11-01T00:03:00Z', ...o });
const rows = [
  ...Array.from({ length: 8 }, () => T({ exit_price: 99.7, realized_pnl: -0.05, close_reason: 'stop_loss' })),
  T({ exit_price: 100.4, realized_pnl: 0.025, close_reason: 'breakeven_trail', closed_at: '2026-11-01T00:20:00Z' }),
  T({ exit_price: 100.4, realized_pnl: 0.025, close_reason: 'breakeven_trail', closed_at: '2026-11-01T00:25:00Z' }),
];
const s = summarize(rows);
ok(s.trades === 10 && s.wins === 2 && s.losses === 8, 'counts');
ok(Math.abs(s.breakEvenWinRate - 0.05 / 0.075) < 1e-9, 'break-even win rate = avgLoss/(avgLoss+avgWin)');
ok(s.reasons[0].reason === 'stop_loss' && s.reasons[0].n === 8, 'worst close_reason bucket first');
ok(Math.abs(s.avgWinMovePct - 0.4) < 1e-9 && Math.abs(s.avgLossMovePct + 0.3) < 1e-9, 'SHORT/LONG-aware realised move %');
ok(s.findings.some((f) => /break-even needs a/.test(f)), 'fee-adjusted break-even finding');
ok(s.findings.some((f) => /Losing trades were bigger/.test(f)) === false, 'equal sizes: no size-asymmetry finding');
ok(s.findings.some((f) => /Winners are cut early/.test(f)), 'early-exit finding (0.4% vs planned 0.9%)');
ok(s.findings.some((f) => /Stops are tight/.test(f)), 'tight stop finding');
ok(s.findings.some((f) => /within 5 minutes/.test(f)), 'noise-stop finding');
const sh = summarize([T({ side: 'SHORT', entry_price: 100, exit_price: 99, realized_pnl: 1, sl_price: 101, tp_price: 98 })]);
ok(Math.abs(sh.avgWinMovePct - 1) < 1e-9, 'short profits when price falls');
ok(summarize([]).trades === 0, 'empty input is safe');
import { inferCloseReason as inf } from '../src/trading/close-reason.js';
ok(inf({ side: 'LONG', entry: 100, exit: 100.65, sl: 99.57, tp: 100.65 }) === 'inferred_tp_hit', 'exit at TP -> tp_hit');
ok(inf({ side: 'LONG', entry: 100, exit: 99.57, sl: 99.57, tp: 100.65 }) === 'inferred_sl_hit', 'exit at SL -> sl_hit');
ok(inf({ side: 'SHORT', entry: 100, exit: 100.43, sl: 100.43, tp: 99.35 }) === 'inferred_sl_hit', 'short stop above entry -> sl_hit');
ok(inf({ side: 'LONG', entry: 100, exit: 100.2, sl: 99.57, tp: 100.65 }) === 'inferred_profit_exit_before_tp', 'small profit -> exit before TP');
ok(inf({ side: 'LONG', entry: 100, exit: 99.9, sl: 99.57, tp: 100.65 }) === 'inferred_loss_exit_before_sl', 'small loss -> exit before SL');
ok(inf({ side: 'LONG', entry: 100, exit: null, sl: 99, tp: 101 }) === 'exchange_close', 'no exit price -> unknown');
const big = summarize([T({ exit_price: 99.7, realized_pnl: -0.1, qty: 30 }), T({ exit_price: 100.9, realized_pnl: 0.02, qty: 5 })]);
ok(big.findings.some((f) => /Losing trades were bigger/.test(f)), 'size-asymmetry finding when losers carry more notional');
console.log(`\n${passed} passed, ${failed} failed`); process.exit(failed ? 1 : 0);
